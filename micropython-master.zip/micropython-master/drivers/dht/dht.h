#include "py/obj.h"

MP_DECLARE_CONST_FUN_OBJ_2(dht_readinto_obj);
